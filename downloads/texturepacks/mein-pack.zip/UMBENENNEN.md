# Mein Pack – Umbenennen-Liste

Item am **Amboss** genau so umbenennen, wie hier geschrieben.
Groß- und Kleinschreibung zählt! Ohne Umbenennen sehen alle Items normal aus.

## Essen (McDonald Food)

| Item | Namen |
|---|---|
| 🍎 Apple | Pear |
| 🥔 Baked Potato | McFries |
| 🍲 Beetroot Soup | Strawberry Soup, Cold Soup |
| 🍞 Bread | Brownie, Candycane, Chocolate Muffin, Gummy Bear |
| 🥩 Cooked Beef | Cheese Burger |
| 🍗 Cooked Chicken | Chicken Nuggets |
| 🍖 Cooked Mutton | Kebab |
| 🥓 Cooked Porkchop | Big Mac, Cooked Bacon |
| 🐟 Cooked Salmon | Fish |
| 🥕 Golden Carrot | Cheese, Banana, Strawberry |
| 🪙 Gold Nugget | Gold Coin |
| 🍯 Honey Bottle | Lemonade, Sprite, Coca Cola, Fanta, Lipton Ice Tea, Hot Chocolate |
| 🔩 Iron Nugget | Silver Coin |
| 🥛 Milk Bucket | Water Ice Cream, Sweet Berries Ice Cream, Melon Popsicle, McFlurry Chocolate, McFlurry, Ice Cream, Cookie Ice Cream, Chorus Ice Cream, Cake Ice Cream, Apple Ice Cream |
| 🍄 Mushroom Stew | Smashed Potato, Ramen |
| 🐷 Porkchop | Raw Bacon |
| 🥧 Pumpkin Pie | Pancakes |
| 🎒 Red Bundle | Happy Meal |
| 🕷️ Spider Eye | Eggchan |
| 🥣 Suspicious Stew | Cereal, Salad |
| 🍒 Sweet Berries | Blueberries, Black Berries, Yellow Raspberry, Raspberry |

## Immer aktiv (ohne Umbenennen)

- **Dreizack** ist golden (Golden Tridents)
- **Feuer** ist niedriger, wenn man brennt (LowOnFire)
- **Kürbis-Kopf** verdeckt die Sicht nicht mehr (No Pumpkin Blur)

## Eigene Items

| Item | Namen |
|---|---|
| 🌿 Dried Kelp | Pill |
