# Mein Pack – Befehle
In den Chat kopieren (Cheats an). Mehr Stück: Zahl ans Ende, z.B. `... 64`.

| Item | Befehl |
|---|---|
| 🍎 Apple | `/give @s apple[custom_name="Pear"]` |
| 🥔 Baked Potato | `/give @s baked_potato[custom_name="McFries"]` |
| 🍲 Beetroot Soup | `/give @s beetroot_soup[custom_name="Cold Soup"]` |
|  | `/give @s beetroot_soup[custom_name="Strawberry Soup"]` |
| 🍞 Bread | `/give @s bread[custom_name="Brownie"]` |
|  | `/give @s bread[custom_name="Chocolate Muffin"]` |
|  | `/give @s bread[custom_name="Candycane"]` |
|  | `/give @s bread[custom_name="Gummy Bear"]` |
| 🥩 Cooked Beef | `/give @s cooked_beef[custom_name="Cheese Burger"]` |
| 🍗 Cooked Chicken | `/give @s cooked_chicken[custom_name="Chicken Nuggets"]` |
| 🍖 Cooked Mutton | `/give @s cooked_mutton[custom_name="Kebab"]` |
| 🥓 Cooked Porkchop | `/give @s cooked_porkchop[custom_name="Cooked Bacon"]` |
|  | `/give @s cooked_porkchop[custom_name="Big Mac"]` |
| 🐟 Cooked Salmon | `/give @s cooked_salmon[custom_name="Fish"]` |
| 🌿 Dried Kelp | `/give @s dried_kelp[custom_name="Pill"]` |
| 🪙 Gold Nugget | `/give @s gold_nugget[custom_name="Gold Coin"]` |
| 🥕 Golden Carrot | `/give @s golden_carrot[custom_name="Banana"]` |
|  | `/give @s golden_carrot[custom_name="Strawberry"]` |
|  | `/give @s golden_carrot[custom_name="Cheese"]` |
| 🍯 Honey Bottle | `/give @s honey_bottle[custom_name="Lipton Ice Tea"]` |
|  | `/give @s honey_bottle[custom_name="Hot Chocolate"]` |
|  | `/give @s honey_bottle[custom_name="Sprite"]` |
|  | `/give @s honey_bottle[custom_name="Fanta"]` |
|  | `/give @s honey_bottle[custom_name="Coca Cola"]` |
|  | `/give @s honey_bottle[custom_name="Lemonade"]` |
| 🔩 Iron Nugget | `/give @s iron_nugget[custom_name="Silver Coin"]` |
| 🥛 Milk Bucket | `/give @s milk_bucket[custom_name="Water Ice Cream"]` |
|  | `/give @s milk_bucket[custom_name="Sweet Berries Ice Cream"]` |
|  | `/give @s milk_bucket[custom_name="Melon Popsicle"]` |
|  | `/give @s milk_bucket[custom_name="McFlurry Chocolate"]` |
|  | `/give @s milk_bucket[custom_name="McFlurry"]` |
|  | `/give @s milk_bucket[custom_name="Ice Cream"]` |
|  | `/give @s milk_bucket[custom_name="Cookie Ice Cream"]` |
|  | `/give @s milk_bucket[custom_name="Chorus Ice Cream"]` |
|  | `/give @s milk_bucket[custom_name="Cake Ice Cream"]` |
|  | `/give @s milk_bucket[custom_name="Apple Ice Cream"]` |
| 🍄 Mushroom Stew | `/give @s mushroom_stew[custom_name="Ramen"]` |
|  | `/give @s mushroom_stew[custom_name="Smashed Potato"]` |
| 🐷 Porkchop | `/give @s porkchop[custom_name="Raw Bacon"]` |
| 🥧 Pumpkin Pie | `/give @s pumpkin_pie[custom_name="Pancakes"]` |
| 🎒 Red Bundle | `/give @s red_bundle[custom_name="Happy Meal"]` |
| 🕷️ Spider Eye | `/give @s spider_eye[custom_name="Eggchan"]` |
| 🥣 Suspicious Stew | `/give @s suspicious_stew[custom_name="Salad"]` |
|  | `/give @s suspicious_stew[custom_name="Cereal"]` |
| 🍒 Sweet Berries | `/give @s sweet_berries[custom_name="Black Berries"]` |
|  | `/give @s sweet_berries[custom_name="Blueberries"]` |
|  | `/give @s sweet_berries[custom_name="Yellow Raspberry"]` |
|  | `/give @s sweet_berries[custom_name="Raspberry"]` |
