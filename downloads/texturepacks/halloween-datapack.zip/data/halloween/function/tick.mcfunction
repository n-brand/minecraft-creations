execute as @a run function halloween:player
